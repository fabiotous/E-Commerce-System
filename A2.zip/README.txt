File I/O and exception handling for 
reading the products.txt file and 
creating Product objects and 
storing in a map -> works

Good use of customized exceptions 
instead of errMsg variable. 
Exceptions thrown and caught 
properly -> works

Cart and CartItem functionality -> works

Correct use of a map for product 
objects -> doesn't work

Use of a map to support the 
printing of product order 
statistics. -> doesn't work

Bonus -> doesn't work

